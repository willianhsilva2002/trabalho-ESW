// Script Principal do Dashboard

document.addEventListener("DOMContentLoaded", () => {
  // Alternância de Seções
  const menuLinks = document.querySelectorAll(".sidebar nav ul li a");
  const sections = document.querySelectorAll(".tab-content");

  function hideAllSections() {
      sections.forEach(section => section.classList.remove("active"));
  }

  function showSection(id) {
      hideAllSections();
      document.querySelector(id).classList.add("active");
  }

  menuLinks.forEach(link => {
      link.addEventListener("click", event => {
          event.preventDefault();
          const targetId = link.getAttribute("href");
          showSection(targetId);
      });
  });

  // Cadastro de Usuários
  const cadastroForm = document.getElementById("cadastroForm");
  const camposAdicionais = document.getElementById("campos_adicionais");

  document.getElementById("tipo_usuario").addEventListener("change", function () {
      const tipo = this.value;
      camposAdicionais.innerHTML = "";

      if (tipo === "residente") {
          camposAdicionais.innerHTML = `
              <label for="historico_medico">Histórico Médico:</label>
              <textarea id="historico_medico" name="historico_medico"></textarea>

              <label for="informacoes_adicionais">Informações Adicionais:</label>
              <textarea id="informacoes_adicionais" name="informacoes_adicionais"></textarea>
          `;
      } else if (tipo === "funcionario") {
          camposAdicionais.innerHTML = `
              <label for="cargo">Cargo:</label>
              <input type="text" id="cargo" name="cargo">
          `;
      } else if (tipo === "voluntario") {
          camposAdicionais.innerHTML = `
              <label for="area_atuacao">Área de Atuação:</label>
              <input type="text" id="area_atuacao" name="area_atuacao">
          `;
      }
  });

  cadastroForm.addEventListener("submit", event => {
      event.preventDefault();
      alert("Usuário cadastrado com sucesso!");
      cadastroForm.reset();
      camposAdicionais.innerHTML = "";
  });

  // Gestão de Perfis
  const usuarios = [];
  const listaUsuarios = document.getElementById("listaUsuarios");

  function carregarUsuarios() {
      listaUsuarios.innerHTML = "";
      usuarios.forEach((usuario, index) => {
          const div = document.createElement("div");
          div.classList.add("card");
          div.innerHTML = `<h3>${usuario.nome}</h3>`;
          div.addEventListener("click", () => abrirModal(usuario, index));
          listaUsuarios.appendChild(div);
      });
  }

  function abrirModal(usuario, index) {
      // Lógica para abrir modal com dados de um usuário específico
  }

  // Histórico e Atividades
  const listaResidentes = document.getElementById("listaResidentes");

  function carregarResidentes() {
      listaResidentes.innerHTML = "";
      usuarios.filter(u => u.tipo === "residente").forEach((residente, index) => {
          const div = document.createElement("div");
          div.classList.add("card");
          div.innerHTML = `<h3>${residente.nome}</h3>`;
          div.addEventListener("click", () => abrirAtividadeModal(residente, index));
          listaResidentes.appendChild(div);
      });
  }

  function abrirAtividadeModal(residente, index) {
      // Lógica para abrir modal de atividades de um residente específico
  }

  // Alertas e Notificações
  const calendario = document.getElementById("calendario");

  function carregarCalendario() {
      const input = document.createElement("input");
      input.type = "date";
      input.id = "inputData";
      input.value = new Date().toISOString().split("T")[0];

      input.addEventListener("change", () => {
          const dataSelecionada = input.value;
          exibirAtividades(dataSelecionada);
      });

      calendario.innerHTML = "";
      calendario.appendChild(input);
      exibirAtividades(input.value); // Mostra atividades do dia atual
  }

  function exibirAtividades(data) {
      const atividades = [
          { data: "2024-12-25", descricao: "Reunião com o médico" },
          { data: "2024-12-26", descricao: "Atividade em grupo" },
          { data: "2024-12-27", descricao: "Consulta de rotina" }
      ];

      const atividadesDoDia = atividades.filter(a => a.data === data);
      const listaExistente = calendario.querySelector("ul");

      if (listaExistente) {
          listaExistente.remove();
      }

      const lista = document.createElement("ul");

      if (atividadesDoDia.length > 0) {
          atividadesDoDia.forEach(atividade => {
              const item = document.createElement("li");
              item.textContent = atividade.descricao;
              lista.appendChild(item);
          });
      } else {
          const item = document.createElement("li");
          item.textContent = "Nenhuma atividade programada para este dia.";
          lista.appendChild(item);
      }

      calendario.appendChild(lista);
  }

  // Inicializar Dashboard
  carregarUsuarios();
  carregarResidentes();
  carregarCalendario();
});
