document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");
    const usernameInput = document.getElementById("username");
    const passwordInput = document.getElementById("password");
    const messageContainer = document.createElement("div");
    messageContainer.id = "login-message";
    messageContainer.style.color = "red";
    messageContainer.style.marginTop = "5px";
    passwordInput.parentNode.appendChild(messageContainer);

    // Usuários cadastrados (dados fictícios)
    const usuarios = [
        { username: "admin", password: "1234" },
        { username: "funcionario", password: "abcd" }
    ];

    // Validação de Login
    form.addEventListener("submit", function (event) {
        event.preventDefault(); // Impede o envio padrão do formulário

        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();

        // Procura o usuário nos dados cadastrados
        const usuarioEncontrado = usuarios.find(user => user.username === username);

        if (usuarioEncontrado) {
            if (usuarioEncontrado.password === password) {
                // Login bem-sucedido
                window.location.href = "index.html"; // Redireciona
            } else {
                // Senha incorreta
                showMessage("Senha incorreta. Tente novamente.");
            }
        } else {
            // Usuário não encontrado
            showMessage("Usuário não cadastrado.");
        }
    });

    // Exibir mensagens de erro
    function showMessage(message) {
        messageContainer.textContent = message;
    }
});
