// Alterna entre as seções do menu
function alternarSecao(idSecao) {
    const secoes = document.querySelectorAll(".section");
    secoes.forEach((secao) => {
        secao.classList.remove("active");
        if (secao.id === idSecao) {
            secao.classList.add("active");
        }
    });
}

// Eventos do menu
document.querySelectorAll("header .menu a").forEach((link) => {
    link.addEventListener("click", (e) => {
        e.preventDefault();
        const idSecao = link.getAttribute("href").substring(1);
        alternarSecao(idSecao);
    });
});

// Dados iniciais fictícios de funcionários e residentes
const funcionarios = [
    { nome: "João Silva", login: "joao.silva", senha: "12345" },
    { nome: "Ana Costa", login: "ana.costa", senha: "senha123" },
    { nome: "Carlos Dias", login: "carlos.dias", senha: "admin" },
];

const residentes = [
    { nome: "João Silva", nascimento: "1945-03-10", contato: "Maria Silva (98765-4321)" },
    { nome: "Ana Costa", nascimento: "1938-07-22", contato: "Carlos Costa (98765-1234)" },
];

// Valida o login do funcionário
function validarLogin(username, password) {
    const funcionario = funcionarios.find((user) => user.login === username);
    if (funcionario) {
        if (funcionario.senha === password) {
            localStorage.setItem("usuarioLogado", JSON.stringify(funcionario));
            return { success: true };
        } else {
            return { success: false, message: "Senha incorreta." };
        }
    }
    return { success: false, message: "Usuário não cadastrado." };
}

// Login (aplicado em login.html)
if (window.location.pathname.includes("login.html")) {
    document.querySelector("form").addEventListener("submit", (e) => {
        e.preventDefault();
        const username = document.querySelector("#username").value.toLowerCase();
        const password = document.querySelector("#password").value;

        const resultado = validarLogin(username, password);
        const loginMessage = document.querySelector("#login-message");

        if (resultado.success) {
            window.location.href = "index.html";
        } else {
            loginMessage.textContent = resultado.message;
        }
    });
}

// Redireciona para login se não estiver autenticado
document.addEventListener("DOMContentLoaded", () => {
    const usuarioLogado = JSON.parse(localStorage.getItem("usuarioLogado"));
    if (window.location.pathname.includes("index.html") && !usuarioLogado) {
        window.location.href = "login.html";
    } else if (usuarioLogado) {
        const nomeUsuario = document.querySelector("#usuario-nome");
        if (nomeUsuario) {
            nomeUsuario.textContent = usuarioLogado.nome;
        }
    }
});

// Atualiza os cards dos residentes (index.html)
function atualizarCards() {
    const container = document.querySelector("#residentes-lista");
    container.innerHTML = "";
    residentes.forEach((residente) => {
        const card = document.createElement("div");
        card.className = "card";
        card.dataset.nome = residente.nome;
        card.innerHTML = `<h3>${residente.nome}</h3>`;
        card.addEventListener("click", () => abrirModal("Editar Residente", residente));
        container.appendChild(card);
    });
}

// Filtro de busca por nome
document.querySelector("#filter-nome")?.addEventListener("input", (e) => {
    const filtro = e.target.value.toLowerCase();
    const cards = document.querySelectorAll(".card");
    cards.forEach((card) => {
        const nome = card.dataset.nome.toLowerCase();
        card.style.display = nome.includes(filtro) ? "block" : "none";
    });
});

// Abre a modal para cadastro ou edição
function abrirModal(titulo, dados = {}) {
    document.querySelector("#modal-title").textContent = titulo;
    document.querySelector("#modal-nome").value = dados.nome || "";
    document.querySelector("#modal-nascimento").value = dados.nascimento || "";
    document.querySelector("#modal-contato").value = dados.contato || "";
    document.querySelector("#modal").classList.remove("hidden");
}

// Fecha a modal sem salvar
document.querySelector("#modal-cancel")?.addEventListener("click", () => {
    document.querySelector("#modal").classList.add("hidden");
});

// Evento para abrir a modal de "Cadastrar Novo Residente"
document.querySelector("#novo-residente")?.addEventListener("click", () => {
    abrirModal("Cadastrar Novo Residente");
});

// Salva o residente ao enviar o formulário na modal
document.querySelector("#modal-form")?.addEventListener("submit", (e) => {
    e.preventDefault();
    const nome = document.querySelector("#modal-nome").value;
    const nascimento = document.querySelector("#modal-nascimento").value;
    const contato = document.querySelector("#modal-contato").value;

    if (document.querySelector("#modal-title").textContent === "Cadastrar Novo Residente") {
        residentes.push({ nome, nascimento, contato });
    } else {
        const index = residentes.findIndex((res) => res.nome === nome);
        if (index !== -1) {
            residentes[index] = { nome, nascimento, contato };
        }
    }
    atualizarCards();
    document.querySelector("#modal").classList.add("hidden");
});


// Máscara para CPF
document.querySelector("#cpf")?.addEventListener("input", (e) => {
    const value = e.target.value.replace(/\D/g, ""); // Remove caracteres não numéricos
    const cpfFormatado = value
        .replace(/(\d{3})(\d)/, "$1.$2")
        .replace(/(\d{3})(\d)/, "$1.$2")
        .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
    e.target.value = cpfFormatado;
});

// Máscara para Telefone
document.querySelector("#telefone")?.addEventListener("input", (e) => {
    const value = e.target.value.replace(/\D/g, ""); // Remove caracteres não numéricos
    const telefoneFormatado = value.length > 10
        ? value.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3")
        : value.replace(/(\d{2})(\d{4})(\d{0,4})/, "($1) $2-$3");
    e.target.value = telefoneFormatado;
});

// Cadastro de usuários
const usuarios = [];

document.querySelector("#cadastro-usuario")?.addEventListener("submit", (e) => {
    e.preventDefault();

    const tipo = document.querySelector("#tipo-usuario").value;
    const nome = document.querySelector("#nome-completo").value;
    const nascimento = document.querySelector("#data-nascimento").value;
    const cpf = document.querySelector("#cpf").value;
    const endereco = document.querySelector("#endereco").value;
    const telefone = document.querySelector("#telefone").value;
    const login = document.querySelector("#login").value.toLowerCase();
    const senha = document.querySelector("#senha").value;

    const novoUsuario = {
        tipo,
        nome,
        nascimento,
        cpf,
        endereco,
        telefone,
        login,
        senha,
    };

    usuarios.push(novoUsuario);
    atualizarUsuariosCadastrados();
    e.target.reset(); // Reseta o formulário
});

// Atualiza a lista de usuários cadastrados
function atualizarUsuariosCadastrados() {
    const container = document.querySelector("#usuarios-cadastrados");
    container.innerHTML = "";

    usuarios.forEach((usuario, index) => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
            <h3>${usuario.nome}</h3>
            <p><strong>Tipo:</strong> ${usuario.tipo}</p>
            <p><strong>CPF:</strong> ${usuario.cpf}</p>
            <p><strong>Telefone:</strong> ${usuario.telefone}</p>
            <button class="btn-secondary" onclick="editarUsuario(${index})">Editar</button>
            <button class="btn-secondary" onclick="excluirUsuario(${index})">Excluir</button>
        `;
        container.appendChild(card);
    });
}

// Edita um usuário
function editarUsuario(index) {
    const usuario = usuarios[index];
    document.querySelector("#tipo-usuario").value = usuario.tipo;
    document.querySelector("#nome-completo").value = usuario.nome;
    document.querySelector("#data-nascimento").value = usuario.nascimento;
    document.querySelector("#cpf").value = usuario.cpf;
    document.querySelector("#endereco").value = usuario.endereco;
    document.querySelector("#telefone").value = usuario.telefone;
    document.querySelector("#login").value = usuario.login;
    document.querySelector("#senha").value = usuario.senha;

    // Substituir o comportamento do botão "Cadastrar Usuário"
    const form = document.querySelector("#cadastro-usuario");
    form.querySelector("button[type='submit']").textContent = "Salvar Alterações";

    form.onsubmit = (e) => {
        e.preventDefault();

        usuario.tipo = document.querySelector("#tipo-usuario").value;
        usuario.nome = document.querySelector("#nome-completo").value;
        usuario.nascimento = document.querySelector("#data-nascimento").value;
        usuario.cpf = document.querySelector("#cpf").value;
        usuario.endereco = document.querySelector("#endereco").value;
        usuario.telefone = document.querySelector("#telefone").value;
        usuario.login = document.querySelector("#login").value.toLowerCase();
        usuario.senha = document.querySelector("#senha").value;

        atualizarUsuariosCadastrados();
        form.reset();
        form.querySelector("button[type='submit']").textContent = "Cadastrar Usuário";
        form.onsubmit = cadastrarUsuario;
    };
}
// Atualiza os cards dos usuários
function atualizarUsuariosCadastrados() {
    const container = document.querySelector("#usuarios-cadastrados");
    container.innerHTML = "";

    usuarios.forEach((usuario, index) => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
            <h3>${usuario.nome}</h3>
            <p><strong>Tipo:</strong> ${usuario.tipo}</p>
            <p><strong>CPF:</strong> ${usuario.cpf}</p>
            <p><strong>Telefone:</strong> ${usuario.telefone}</p>
            <button class="btn-secondary" onclick="abrirModalEditar(${index})">Editar</button>
            <button class="btn-secondary" onclick="excluirUsuario(${index})">Excluir</button>
        `;
        container.appendChild(card);
    });
}

// Abre a modal para edição
function abrirModalEditar(index) {
    const usuario = usuarios[index];
    document.querySelector("#modal-tipo-usuario").value = usuario.tipo;
    document.querySelector("#modal-nome-completo").value = usuario.nome;
    document.querySelector("#modal-data-nascimento").value = usuario.nascimento;
    document.querySelector("#modal-cpf").value = usuario.cpf;
    document.querySelector("#modal-endereco").value = usuario.endereco;
    document.querySelector("#modal-telefone").value = usuario.telefone;
    document.querySelector("#modal-login").value = usuario.login;
    document.querySelector("#modal-senha").value = usuario.senha;

    document.querySelector("#modal-editar-usuario").classList.remove("hidden");

    // Atualiza as informações ao salvar
    const form = document.querySelector("#editar-usuario-form");
    form.onsubmit = (e) => {
        e.preventDefault();

        usuario.tipo = document.querySelector("#modal-tipo-usuario").value;
        usuario.nome = document.querySelector("#modal-nome-completo").value;
        usuario.nascimento = document.querySelector("#modal-data-nascimento").value;
        usuario.cpf = document.querySelector("#modal-cpf").value;
        usuario.endereco = document.querySelector("#modal-endereco").value;
        usuario.telefone = document.querySelector("#modal-telefone").value;
        usuario.login = document.querySelector("#modal-login").value.toLowerCase();
        usuario.senha = document.querySelector("#modal-senha").value;

        atualizarUsuariosCadastrados();
        fecharModalEditar();
    };
}

// Fecha a modal de edição
function fecharModalEditar() {
    document.querySelector("#modal-editar-usuario").classList.add("hidden");
    document.querySelector("#editar-usuario-form").reset();
}

// Adiciona evento ao botão de cancelar edição
document.querySelector("#modal-cancelar-edicao")?.addEventListener("click", fecharModalEditar);

// Exclui um usuário
function excluirUsuario(index) {
    if (confirm("Deseja realmente excluir este usuário?")) {
        usuarios.splice(index, 1);
        atualizarUsuariosCadastrados();
    }
}
const monthNames = [
    "Janeiro", "Fevereiro", "Março", "Abril",
    "Maio", "Junho", "Julho", "Agosto",
    "Setembro", "Outubro", "Novembro", "Dezembro"
];

let currentDate = new Date();

let activities = {};

// Renderiza o calendário com bolinhas verdes
function renderCalendar() {
    const monthYearDiv = document.getElementById('monthYear');
    const calendarDiv = document.getElementById('calendar');

    monthYearDiv.textContent = `${monthNames[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
    calendarDiv.innerHTML = '';

    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

    for (let i = 0; i < firstDay.getDay(); i++) {
        calendarDiv.innerHTML += '<div></div>';
    }

    for (let day = 1; day <= lastDay.getDate(); day++) {
        const dayDiv = document.createElement('div');
        dayDiv.className = 'day';
        dayDiv.textContent = day;

        if (activities[day]) {
            dayDiv.classList.add('has-activity');
        }

        dayDiv.addEventListener('click', () => selectDay(day));
        calendarDiv.appendChild(dayDiv);
    }
}

// Seleciona o dia no calendário
function selectDay(day) {
    document.getElementById('selectedDay').textContent = day;
    const dayName = new Date(currentDate.getFullYear(), currentDate.getMonth(), day).toLocaleDateString('pt-BR', { weekday: 'long' });
    document.getElementById('selectedDayName').textContent = dayName.toUpperCase();

    updateActivityList(day);
}

// Atualiza a lista de atividades por residente
function updateActivityList(day) {
    const activityDetails = document.getElementById('activityDetails');
    activityDetails.innerHTML = '';

    const activitiesForDay = activities[day] || [];
    const residents = [...new Set(activitiesForDay.map(activity => activity.residente))];

    if (residents.length > 0) {
        residents.forEach(resident => {
            const li = document.createElement('li');
            li.textContent = resident;
            li.addEventListener('click', () => showResidentDetails(day, resident));
            activityDetails.appendChild(li);
        });
    } else {
        activityDetails.textContent = 'Nenhuma atividade registrada para este dia.';
    }
}

// Exibe os detalhes das atividades de um residente
function showResidentDetails(day, resident) {
    const activitiesForDay = activities[day] || [];
    const details = activitiesForDay.filter(activity => activity.residente === resident || resident === 'todos');

    alert(details.map(detail => `${detail.tipo} - ${detail.horario} - ${detail.local}`).join('\n'));
}

// Registra uma nova atividade
document.getElementById('activityForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const tipo = document.getElementById('tipo').value;
    const residente = document.getElementById('residente').value;
    const horario = document.getElementById('horario').value;
    const local = document.getElementById('local').value;
    const descricao = document.getElementById('descricao').value;
    const selectedDay = parseInt(document.getElementById('selectedDay').textContent);

    if (!activities[selectedDay]) {
        activities[selectedDay] = [];
    }

    activities[selectedDay].push({ tipo, residente, horario, local, descricao });
    document.getElementById('activityForm').reset();
    renderCalendar();
    selectDay(selectedDay);
});

// Navegação de meses
document.getElementById('prevMonth').addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar();
});

document.getElementById('nextMonth').addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar();
});

// Inicializa o calendário
renderCalendar();
selectDay(new Date().getDate());

// Inicializa os dados fictícios e exibe os cards (index.html)
document.addEventListener("DOMContentLoaded", () => {
    atualizarCards();
});